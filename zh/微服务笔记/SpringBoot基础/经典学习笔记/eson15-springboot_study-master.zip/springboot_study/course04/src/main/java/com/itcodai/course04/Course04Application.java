package com.itcodai.course04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course04Application {

	public static void main(String[] args) {
		SpringApplication.run(Course04Application.class, args);
	}
}
