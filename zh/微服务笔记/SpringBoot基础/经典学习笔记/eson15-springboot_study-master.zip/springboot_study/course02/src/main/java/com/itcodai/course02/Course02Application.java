package com.itcodai.course02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course02Application {

	public static void main(String[] args) {
		SpringApplication.run(Course02Application.class, args);
	}
}
