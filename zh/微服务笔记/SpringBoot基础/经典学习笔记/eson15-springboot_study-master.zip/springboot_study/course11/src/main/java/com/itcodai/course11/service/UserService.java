package com.itcodai.course11.service;

import com.itcodai.course11.entity.User;

public interface UserService {

    void isertUser(User user);
    void isertUser2(User user) throws Exception;
    void isertUser3(User user);
    void isertUser4(User user);
}
