package com.itcodai.course01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course01Application {

	public static void main(String[] args) {

		SpringApplication.run(Course01Application.class, args);
	}
}
