package com.itcodai.course06;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course06Application {

	public static void main(String[] args) {
		SpringApplication.run(Course06Application.class, args);
	}
}
