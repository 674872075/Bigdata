package com.itcodai.course15;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course15Application {

	public static void main(String[] args) {
		SpringApplication.run(Course15Application.class, args);
	}
}
