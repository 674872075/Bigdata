package com.itcodai.course08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course08Application {

	public static void main(String[] args) {
		SpringApplication.run(Course08Application.class, args);
	}
}
