package com.itcodai.course05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course05Application {

	public static void main(String[] args) {
		SpringApplication.run(Course05Application.class, args);
	}
}
