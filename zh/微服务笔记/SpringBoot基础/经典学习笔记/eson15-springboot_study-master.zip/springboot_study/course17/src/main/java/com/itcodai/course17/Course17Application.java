package com.itcodai.course17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course17Application {

	public static void main(String[] args) {
		SpringApplication.run(Course17Application.class, args);
	}
}
