package com.itcodai.course03.dao;

public interface UserMapper {

    void deleteUser(Long id);
}
