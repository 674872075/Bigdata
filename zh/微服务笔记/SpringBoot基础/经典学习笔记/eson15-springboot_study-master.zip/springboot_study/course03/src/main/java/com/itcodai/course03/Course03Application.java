package com.itcodai.course03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course03Application {

	public static void main(String[] args) {
		SpringApplication.run(Course03Application.class, args);
	}
}
