package com.itcodai.course09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Course09Application {

	public static void main(String[] args) {
		SpringApplication.run(Course09Application.class, args);
	}
}
